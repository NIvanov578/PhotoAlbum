import React from 'react';
import './Card.css';

function Card({ title, render, classWrapper }) {
  return (
    <section className={`card ${classWrapper}`}>
      <div className="cell">
        {render && render()}
        <h4>{title}</h4>
      </div>
    </section>
  );
}

export default Card;
