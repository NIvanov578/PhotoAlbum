import React, { Component } from 'react';
import { connect } from 'react-redux';
import AlbumPhotos from '../components/AlbumPhotos';
class Favourites extends Component {
  render() {
    const { favourites } = this.props;
    return (
      <>
        <AlbumPhotos
          photos={favourites}
          message="Sorry. You don't have any favourites photos!"
        />
      </>
    );
  }
}

function mapStateToProps(state) {
  const { favourites } = state;

  return {
    favourites,
  };
}

export default connect(mapStateToProps, null)(Favourites);
