import React from 'react';

function Photo({ url, thumbnailUrl }) {
  return (
    <>
      <img src={thumbnailUrl} alt={thumbnailUrl} width="150" height="150" />
    </>
  );
}

export default Photo;
