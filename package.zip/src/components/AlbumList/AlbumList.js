import React from 'react';
import PageWrapper from '../PageWrapper/PageWrapper';
import Page from '../Page/Page';
import Card from '../Card/Card';
import { Link } from 'react-router-dom';

export default function ({ albumIds = [], pathname }) {
  return (
    <PageWrapper>
      <Page>
        {albumIds.map((el) => {
          return (
            <Link to={`${pathname}/${el}`}>
              <Card
                key={`key-${el}`}
                title={`Album ${el}`}
                classWrapper="flex"
              />
            </Link>
          );
        })}
      </Page>
    </PageWrapper>
  );
}
