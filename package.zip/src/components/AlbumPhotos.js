import React from 'react';
import Photo from './Photo/Photo';
import Card from './Card/Card';
import PageWrapper from './PageWrapper/PageWrapper';
import Page from './Page/Page';

export default function ({
  photos = [],
  showButton,
  toggleFavourites,
  message,
}) {
  return (
    <PageWrapper>
      <Page>
        {photos.length > 0 ? (
          photos.map((photo, index) => {
            return (
              <div key={`key-${photo.albumId}-${photo.id}`}>
                <Card title={photo.title} render={() => <Photo {...photo} />} />
                {showButton && (
                  <button
                    onClick={() => toggleFavourites(photo, photo.isFavourite)}
                  >
                    {photo.isFavourite ? 'Remove' : 'Add To Favourites'}
                  </button>
                )}
              </div>
            );
          })
        ) : (
          <h2>{message}</h2>
        )}
      </Page>
    </PageWrapper>
  );
}
