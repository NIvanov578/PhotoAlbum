import React from 'react';

function Footer() {
  return <footer>Footer</footer>;
}

export default Footer;
